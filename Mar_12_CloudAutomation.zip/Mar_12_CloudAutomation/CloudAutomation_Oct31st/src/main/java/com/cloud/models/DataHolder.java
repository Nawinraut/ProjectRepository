package com.cloud.models;

public class DataHolder {

	public static String methodName="";
	public static String recepientName="";
	public static String bookingPrice="";
	public static String bookingDate="";
	public static String devicetype="";
	public static String pagesourcepath="";
	public static String UserType="";
	public static String UserName="";
	public static String UserMailID="";
}
