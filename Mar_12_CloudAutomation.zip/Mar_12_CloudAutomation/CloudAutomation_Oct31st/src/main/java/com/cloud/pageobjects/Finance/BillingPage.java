package com.cloud.pageobjects.Finance;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cloud.exceptions.TestException;
import com.cloud.models.Item;
import com.cloud.pageobjects.BasePageObject;
import com.cloud.utils.Screenshot;
import com.cloud.utils.SeleniumUtils;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BillingPage extends BasePageObject{
	public WebDriver driver;
	
	 @FindBy(how=How.XPATH, using = "//img[contains(@id,'_FndTasksList::icon')]")
	    private WebElement btnTasks;
	 
	 @FindBy(how=How.XPATH, using = "//*[@id='_FOpt1:_FOr1:0:_FOSritemNode_receivables_billing:0:_FOTRaT:0:RAtl1']")
	    private WebElement lnkCreateTransaction;
	 
	 @FindBy(how=How.XPATH, using = "//a[contains(.,'Create Accounting')]")
	    private WebElement lnkCreateAccounting;
	 
	 @FindBy(how=How.XPATH, using = "//a[contains(.,'Manage Transactions')]")
	    private WebElement lnkManageTransactions;
	 
	 @FindBy(how=How.XPATH, using = "//a[contains(.,'Create Customer')]")
	    private WebElement lnkCreateCustomer;
	 
	 
	 public WebDriverWait wdwait; 
		/**
		* Initializing page objects for Journal Page.
		* @author Ciber
		* @param driver
		* @return
		* @throws TestException
		*/
	    
	    
	    public BillingPage(WebDriver driver, ExtentTest report) throws TestException {
		     super(report);
			 this.driver=driver; 
			 wdwait=new WebDriverWait(driver, 60);
		     PageFactory.initElements(driver, this);
		    
		     wdwait.until(ExpectedConditions.visibilityOf(btnTasks));
		     if (!isDisplayed()) 
		     {
		        throw new TestException(this.getClass().getName() + " is not loaded");
		     }
		     
		     
		        System.out.println("******************************* Billing Page *****************************");
		       this.getScreenDetails();
		    }

	 
	    public boolean isTasksBtnDisplayed(){
	    	return SeleniumUtils.isDisplayed(driver, btnTasks, context.getReactTimeout());
	    	
	    }
	    public void clickTasksButton(){
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	js.executeScript("arguments[0].click();", btnTasks);
	    	//btnTasks.click();
	    	wdwait.until(ExpectedConditions.visibilityOf(lnkCreateTransaction));
	    	report.log(LogStatus.PASS, "Clicked on Tasks Button");
	    }
	    
	    public CreateTransactionPage clickCreateTransactionLink()throws TestException{
	    	lnkCreateTransaction.click();
	    	report.log(LogStatus.PASS, "Clicked on Create Transaction Link");
	    	return new CreateTransactionPage(driver,report);
	    }
	    
	   
	    public boolean isCreateTransactionLinkDisplayed(){
	    	return SeleniumUtils.isDisplayed(driver, lnkCreateTransaction, context.getReactTimeout());
	    	
	    }
	    
	    
	    public CreateReceivablesAccounting_BasicOptionsPage clickCreateAccountingLink()throws TestException{
	    	lnkCreateAccounting.click();
	    	report.log(LogStatus.PASS, "Clicked on Create Accounting Link");
	    	return new CreateReceivablesAccounting_BasicOptionsPage(driver,report);
	    }
	    
	   
	    public boolean isCreateAccountingLinkDisplayed(){
	    	return lnkCreateAccounting.isDisplayed();
	    	
	    }
	    
	    //Manage Transactions link
	    
	    public ManageTransactionsPage clickManageTransactionsLink()throws TestException{
	    	lnkManageTransactions.click();
	    	report.log(LogStatus.PASS, "Clicked on Manage Transactions Link");
	    	return new ManageTransactionsPage(driver,report);
	    }
	    
	   
	    public boolean isManageTransactionsLinkDisplayed(){
	    	return lnkManageTransactions.isDisplayed();
	    	
	    }
	    
	    
	  //CreateOrganizationCustomerPage
	    public CreateOrganizationCustomerPage clickCreateCustomerLink()throws TestException{
	    	lnkCreateCustomer.click();
	    	report.log(LogStatus.PASS, "Clicked on Create Customer Link");
	    	return new CreateOrganizationCustomerPage(driver,report);
	    }
	    
	    @Override
		public boolean isDisplayed() {
			// TODO Auto-generated method stub
			//return  btnTasks.isDisplayed();
			
			 report.log(LogStatus.PASS, "Billing Page is Loaded Successfully");
	    	 if(btnTasks.isDisplayed())
	    	 {
	    		 return true;
	    		 
	    	 } else {
	    		 return false;
	    	 }     	
		}
		
		public Item getScreenDetails(String strTitle){
	        String xyz = Screenshot.takeScreenshotX(driver, strTitle, context);
	        report.addScreenCapture(xyz);
	        String projectPath = System.getProperty("user.dir");          
	        String fullprojectPath = projectPath+"/report/"+xyz;
	        report.log(LogStatus.INFO, "<a href='"+fullprojectPath+"'><span class='label info'>"+strTitle+"</span></a>");
	        return new Item(xyz);
	    }
	    
	    
		public Item getScreenDetails(){
		   	String xyz = Screenshot.takeScreenshotX(driver, "EntryLogin", context);
		   	report.addScreenCapture(xyz);
		   	String projectPath = System.getProperty("user.dir");    	
		   	String fullprojectPath = projectPath+"/report/"+xyz;
		   	report.log(LogStatus.INFO, "<a href='"+fullprojectPath+"'><span class='label info'>Billing Page</span></a>");
		   	return new Item(xyz);
	   }

}
