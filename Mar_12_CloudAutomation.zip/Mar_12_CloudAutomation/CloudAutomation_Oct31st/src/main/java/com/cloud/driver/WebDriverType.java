package com.cloud.driver;

public enum WebDriverType {
	
	chrome,ie,firefox;

}
